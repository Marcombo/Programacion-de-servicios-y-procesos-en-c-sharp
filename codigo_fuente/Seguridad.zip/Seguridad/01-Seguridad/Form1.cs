﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Text;

namespace _01_Seguridad {
  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }

    private void button1_Click(object sender, EventArgs e) {
      String nombreFichero;

      if (openFileDialog1.ShowDialog() == DialogResult.OK) {
        nombreFichero = openFileDialog1.FileName;
        MD5 md5 = MD5.Create();
        FileStream stream = File.OpenRead(nombreFichero);
        byte[] hash = md5.ComputeHash(stream);

        this.label1.Text += BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
      }
    }

    private void button2_Click(object sender, EventArgs e) {
      String alfabeto = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ0123456789 ";
      String alfabetoCifrado = "KLMNÑOPQRSTUVWXYZ0123456789 ABCDEFGHIJ";

      String mensaje, mensajeCifrado = "";
      mensaje = this.textBox1.Text;
      for (int i = 0; i < mensaje.Length; i++) {
        mensajeCifrado += alfabetoCifrado.Substring(alfabeto.IndexOf(mensaje.Substring(i, 1).ToUpper()), 1);
      }
      this.label2.Text += mensajeCifrado;
    }

    private void button3_Click(object sender, EventArgs e) {
      try {
        //al crear un objeto DES se genera la key y el vector IV
        DES objDES = DES.Create();

        string textoMensaje = this.textBox2.Text;
        string textoCifrado, textoDescifrado;
        string fichero = "encriptaDES.txt";

        textoCifrado = EncryptTextToFile(textoMensaje, fichero, objDES.Key, objDES.IV);
        textoDescifrado = DecryptTextFromFile(fichero, objDES.Key, objDES.IV);

        this.label3.Text = textoCifrado;
        this.label4.Text = textoDescifrado;
      }
      catch (Exception exc) {
        Console.WriteLine(exc.Message);
      }
    }
    public static string EncryptTextToFile(String Data, String FileName, byte[] Key, byte[] IV) {
      try {
        FileStream fStream = File.Open(FileName, FileMode.OpenOrCreate);
        DES DESalg = DES.Create();
        CryptoStream cStream = new CryptoStream(fStream,
            DESalg.CreateEncryptor(Key, IV),
            CryptoStreamMode.Write);
        StreamWriter sWriter = new StreamWriter(cStream);
        sWriter.WriteLine(Data);
        sWriter.Close();
        cStream.Close();
        //fStream.Close();
        fStream = File.Open(FileName, FileMode.Open);
        StreamReader sr = new StreamReader(fStream);
        string cifrado = sr.ReadToEnd();
        fStream.Close();
        return (cifrado);
      }
      catch (CryptographicException e) {
        Console.WriteLine("Error criptográfico: {0}", e.Message);
        return null;
      }
      catch (UnauthorizedAccessException e) {
        Console.WriteLine("Error acceso a ficheros: {0}", e.Message);
        return null;
      }
    }

    public static string DecryptTextFromFile(String FileName, byte[] Key, byte[] IV) {
      try {
        FileStream fStream = File.Open(FileName, FileMode.Open);// .OpenOrCreate);
        DES DESalg = DES.Create();
        CryptoStream cStream = new CryptoStream(fStream,
            DESalg.CreateDecryptor(Key, IV),
            CryptoStreamMode.Read);
        StreamReader sReader = new StreamReader(cStream);
        string descifrado = sReader.ReadToEnd();
        sReader.Close();
        cStream.Close();
        fStream.Close();
        return descifrado;
      }
      catch (CryptographicException e) {
        Console.WriteLine("Error criptográfico: {0}", e.Message);
        return null;
      }
      catch (UnauthorizedAccessException e) {
        Console.WriteLine("Error acceso a ficheros: {0}", e.Message);
        return null;
      }
    }


    private void button4_Click(object sender, EventArgs e) {
      string original = this.textBox3.Text;

      //al crear un objeto AES se genera la key y el vector IV
      using (Aes myAes = Aes.Create()) {
        byte[] textoEncriptado = EncryptStringToBytes_Aes(original, myAes.Key, myAes.IV);
        string textoDesencriptado = DecryptStringFromBytes_Aes(textoEncriptado, myAes.Key, myAes.IV);

        this.label5.Text = BitConverter.ToString(textoEncriptado);
        this.label6.Text = textoDesencriptado;
      }
    }
    static byte[] EncryptStringToBytes_Aes(string plainText, byte[] Key, byte[] IV) {
      byte[] encrypted;
      using (Aes aesAlg = Aes.Create()) {
        aesAlg.Key = Key;
        aesAlg.IV = IV;
        ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
        using (MemoryStream msEncrypt = new MemoryStream()) {
          using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write)) {
            using (StreamWriter swEncrypt = new StreamWriter(csEncrypt)) {
              swEncrypt.Write(plainText);
            }
            encrypted = msEncrypt.ToArray();
          }
        }
      }
      return encrypted;
    }
    static string DecryptStringFromBytes_Aes(byte[] cipherText, byte[] Key, byte[] IV) {
      string plaintext = null;
      using (Aes aesAlg = Aes.Create()) {
        aesAlg.Key = Key;
        aesAlg.IV = IV;
        ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
        using (MemoryStream msDecrypt = new MemoryStream(cipherText)) {
          using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read)) {
            using (StreamReader srDecrypt = new StreamReader(csDecrypt)) {
              plaintext = srDecrypt.ReadToEnd();
            }
          }
        }
      }
      return plaintext;
    }

    private void button5_Click(object sender, EventArgs e) {
      string mensaje = this.textBox4.Text;
      string publicKeyFile = "publicKey.xml";
      string privateKeyFile = "privateKey.xml";
      generarClaves(publicKeyFile, privateKeyFile);

      byte[] Encriptado = encriptar(publicKeyFile, Encoding.UTF8.GetBytes(mensaje));
      byte[] Desencriptado = Desencriptar(privateKeyFile, Encriptado);

      this.label7.Text = BitConverter.ToString(Encriptado);
      this.label8.Text =Encoding.UTF8.GetString(Desencriptado);
    }

    private static void generarClaves(string publicKF, string privateKF) {
      using (var rsa = new RSACryptoServiceProvider(2048)) {
        rsa.PersistKeyInCsp = false;

        if (File.Exists(publicKF))
          File.Delete(publicKF);
        if (File.Exists(privateKF))
          File.Delete(privateKF);

        string publicKey = rsa.ToXmlString(false);
        File.WriteAllText(publicKF, publicKey);
        string privateKey = rsa.ToXmlString(true);
        File.WriteAllText(privateKF, privateKey);
      }
    }

    public static byte[] encriptar(string publicKF, byte[] textoPlano) {
      byte[] encriptado;
      using (var rsa = new RSACryptoServiceProvider(2048)) {
        rsa.PersistKeyInCsp = false;
        string publicKey = File.ReadAllText(publicKF);
        rsa.FromXmlString(publicKey);
        encriptado = rsa.Encrypt(textoPlano, true);      
      }
      return (encriptado);
    }
    public static byte[] Desencriptar(string privateKF, byte[] textoEncriptado) {
      byte[] Desencriptado;
      using (var rsa = new RSACryptoServiceProvider(2048)) {
        rsa.PersistKeyInCsp = false;
        string privateKey = File.ReadAllText(privateKF);
        rsa.FromXmlString(privateKey);
        Desencriptado = rsa.Decrypt(textoEncriptado, true);
      }
      return (Desencriptado);
    }
  }
}

