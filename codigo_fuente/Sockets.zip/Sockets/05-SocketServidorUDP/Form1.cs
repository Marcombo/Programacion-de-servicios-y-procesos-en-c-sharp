﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _05_SocketServidorUDP {
  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }

    private void button1_Click(object sender, EventArgs e) {
      int numDatos;
      byte[] byteRecibidos = new byte[1000];
      byte[] byteEnviados = new byte[1000];

      Socket miSocketServidor = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
      IPEndPoint miDireccionEscucha = new IPEndPoint(IPAddress.Any, 2000);
      try {
        miSocketServidor.Bind(miDireccionEscucha);

        IPEndPoint receptor = new IPEndPoint(IPAddress.Any, 0);
        EndPoint remoto = (EndPoint)(receptor);

        //recepción de datos
        numDatos = miSocketServidor.ReceiveFrom(byteRecibidos, ref remoto);
        Debug.WriteLine("Datos recibidos del cliente: " + remoto.ToString());
        this.label1.Text = Encoding.ASCII.GetString(byteRecibidos, 0, numDatos);

        //envío de datos
        byteEnviados = Encoding.ASCII.GetBytes(this.textBox1.Text);
        miSocketServidor.SendTo(byteEnviados, byteEnviados.Length, SocketFlags.None, remoto);

        miSocketServidor.Close();
      }
      catch (Exception error) {
        Debug.WriteLine("Error: {0}", error.ToString());
      }
    }
  }
}
