﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _00_Networking {
  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }

    private void button1_Click(object sender, EventArgs e) {
      IPAddress IP1 = IPAddress.Parse("172.156.11.1");
      IPAddress IP2 = IPAddress.Loopback;
      IPAddress IP3 = IPAddress.Broadcast;
      IPAddress IP4 = IPAddress.Any;
      IPAddress IP5 = IPAddress.None;

      Debug.WriteLine("IP transformada: " + IP1.ToString());
      Debug.WriteLine("IP loopback: " + IP2.ToString());
      Debug.WriteLine("IP broadcast: " + IP3.ToString());
      Debug.WriteLine("IP any: " + IP4.ToString());
      Debug.WriteLine("IP none: " + IP5.ToString());
    }

    private void button2_Click(object sender, EventArgs e) {
      IPHostEntry ihe = Dns.GetHostEntry(Dns.GetHostName());
      Debug.WriteLine ("Nombrehost: " + Dns.GetHostName());
      foreach (IPAddress ip in ihe.AddressList) {
        if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
          Debug.WriteLine(ip.ToString());
      }
    }

    private void button3_Click(object sender, EventArgs e) {
      IPAddress ip1 = IPAddress.Parse("142.250.184.164");
      IPEndPoint ie = new IPEndPoint(ip1, 80);
      Debug.WriteLine("El IPEndPoint es: " + ie.ToString());
      Debug.WriteLine("La familia del protocolo es: " + ie.AddressFamily);
    }

    private void button4_Click(object sender, EventArgs e) {
      IPHostEntry resultados = Dns.GetHostEntry("www.marcombo.com");
      //IPHostEntry resultados = Dns.GetHostEntry("www.microsoft.net");
      foreach (IPAddress ip in resultados.AddressList)
        Debug.WriteLine(ip.ToString());
    }

    private void button5_Click(object sender, EventArgs e) {
      try {
        String IP = "216.58.209.69";
        IPHostEntry host = Dns.GetHostEntry(IP);
        Debug.WriteLine("La IP " + IP + " tiene una entrada DNS: " + host.HostName);
      }
      catch (Exception ex) {
        Debug.WriteLine(ex.Message);
      }     
    }
  }
}
