﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace _03_SocketServidorDatos {
  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }

    private void Button1_Click(object sender, EventArgs e) {
      Socket miSocketServidor = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
      IPEndPoint miDireccionEscucha = new IPEndPoint(IPAddress.Any, 2000);
      try {
        miSocketServidor.Bind(miDireccionEscucha);
        miSocketServidor.Listen(1);

        //esta línea es bloqueante
        Socket cliente = miSocketServidor.Accept();

        Debug.WriteLine("Conexión exitosa del cliente: " +
            cliente.RemoteEndPoint.ToString());

        //recepción de datos
        byte[] byteRecibidos = new byte[1000];
        int datos = cliente.Receive(byteRecibidos, 0, byteRecibidos.Length, SocketFlags.None);
        this.label1.Text = Encoding.Default.GetString(byteRecibidos, 0, datos);

        cliente.Close();
        miSocketServidor.Close();

      }
      catch (Exception error) {
        Debug.WriteLine("Error: {0}", error.ToString());
      }
    }
  }
}
