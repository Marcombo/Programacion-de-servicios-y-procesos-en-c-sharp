﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace _01_IntroProcesos {
  public partial class Form1 : Form {
    Process miProceso;
    public Form1() {
      InitializeComponent();
    }

    private void Button1_Click(object sender, EventArgs e) {
      //referencia https://docs.microsoft.com/es-es/dotnet/api/system.diagnostics.process?view=netframework-4.8

      miProceso = new Process();
      miProceso.StartInfo.FileName = "Notepad";
      //miProceso.StartInfo.FileName = @"C:\Program Files\LibreOffice\program\swriter.exe";
      //miProceso.StartInfo.FileName = @"C:\Program Files(x86)\Microsoft Office\Office16\WINWORD.exe";
      //miProceso.StartInfo.WindowStyle = ProcessWindowStyle.Maximized;
      miProceso.Start();

    }

    private void Button2_Click(object sender, EventArgs e) {
      miProceso.Kill();
    }

    private void Button3_Click(object sender, EventArgs e) {
      Process[] misProcesos = Process.GetProcesses();
      this.comboBox1.Items.Clear();
      foreach (Process mp in misProcesos) {
        this.comboBox1.Items.Add(mp.ProcessName);
      }
    }

    private void Button4_Click(object sender, EventArgs e) {
      Process[] misProcesos = Process.GetProcessesByName("chrome");
      this.comboBox1.Items.Clear();
      foreach (Process mp in misProcesos) {
        this.comboBox1.Items.Add(mp.ProcessName);
      }
    }

    private void Button5_Click(object sender, EventArgs e) {
      Process[] misProcesos = Process.GetProcessesByName("Chrome");
      foreach (Process mp in misProcesos) {
        mp.Kill();
      }
    }

    private void button6_Click(object sender, EventArgs e) {
      try {
        Process.Start(@"C:\Windows\System32\notepad.exe");
        Process.Start("calc");
        Process.Start("MiDocumento.pdf");
        Process.Start("https:\\www.marcombo.com");
        Process.Start("C:\\");
      }
      catch (Exception ex) {
        Debug.WriteLine(ex.Message);
      }
    }

    private void button7_Click(object sender, EventArgs e) {
      ProcessStartInfo psi = new ProcessStartInfo();
      psi.FileName = "ping";
      psi.CreateNoWindow = false;
      psi.UseShellExecute = true;
      psi.WindowStyle = ProcessWindowStyle.Maximized;
      psi.Arguments = "www.marcombo.com" + " -n 10";
      try {
        Process.Start(psi);
      }
      catch (Exception ex) {
        Debug.WriteLine(ex.Message);
      }
    }

    private void button8_Click(object sender, EventArgs e) {
      //iniciamos un proceso
      miProceso = new Process();
      miProceso.StartInfo.FileName = "Notepad";
      miProceso.Start();

      //consultamos alguna propiedad y alteramos alguna otra
      Debug.WriteLine( miProceso.StartTime.ToString());
      miProceso.PriorityClass = ProcessPriorityClass.BelowNormal;
    }

    private void button9_Click(object sender, EventArgs e) {
      //se debe ejecutar previamente a la creación de un proceso
      String nombre = miProceso.ProcessName;
      Debug.WriteLine(miProceso.HasExited.ToString());
      miProceso.WaitForExit(); //método síncrono=>línea bloqueante
      Debug.WriteLine(miProceso.HasExited.ToString());
      Debug.WriteLine(miProceso.ExitCode.ToString());
      Debug.WriteLine("El proceso " + nombre + "ha terminado");
    }

    private void button10_Click(object sender, EventArgs e) {
      ProcessStartInfo psi = new ProcessStartInfo();
      psi.FileName = "cmd.exe";
      psi.Arguments = "/c dir";
      psi.UseShellExecute = false;
      psi.CreateNoWindow = true;
      psi.RedirectStandardOutput = true;     

      Process p = Process.Start(psi);
      StreamReader reader = p.StandardOutput;

      string datos = reader.ReadToEnd();
      Debug.WriteLine(datos);
    }

    [DllImport("user32.dll", EntryPoint = "FindWindowEx")]
    public static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);
    [DllImport("User32.dll")]
    public static extern int SendMessage(IntPtr hWnd, int uMsg, int wParam, string lParam);

    private void button11_Click(object sender, EventArgs e) {
      Process[] processes = Process.GetProcessesByName("notepad");
      //Console.WriteLine(processes[0].MainWindowHandle.ToString());
      if (processes.Length == 0) return;
      if (processes[0] != null) {
        IntPtr child = FindWindowEx(processes[0].MainWindowHandle, new IntPtr(0), "Edit", null);
        SendMessage(child, 0x000C, 0, "hola");
      }
    }
  }
}
