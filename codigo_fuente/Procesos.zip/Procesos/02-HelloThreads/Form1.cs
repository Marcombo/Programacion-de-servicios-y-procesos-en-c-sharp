﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace _02_HelloThreads
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //referencia pag 9 threading.pdf
            Thread t = new Thread(this.Go);
            t.Start();

            this.Go();
        }

        private void Go()
        {
            Debug.WriteLine("Hola");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(this.EscribeY);
            t.Start();
            for (int i = 0; i < 1000; i++)
            {
                Debug.Write("X");
            }

        }

        private void EscribeY()
        {
            for (int i=0; i<1000; i++)
            {
                Debug.Write("y");
            }
        }

        bool Done;
        private void Button3_Click(object sender, EventArgs e)
        {
            this.Done = false;
            Thread t = new Thread(this.GoFeito);
            t.Start();
            this.GoFeito();
        }

        private void GoFeito()
        {
            if (!Done)
            {
                Debug.WriteLine("Ola, está Feito");
                this.Done = true;
            }
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            //primera forma de pasar parámetros
            Thread t1 = new Thread( () => this.Mensaje ("Adrián") );
            t1.Start();

            //segunda forma de pasar parámetros
            Thread t2 = new Thread(this.Mensaje2);
            t2.Start("Marcos");

            this.Mensaje("JuanJosé");
        }

        private void Mensaje(string nombre)
        {
            Debug.WriteLine("Hola " + nombre);
        }

        private void Mensaje2(object nombre)
        {
            String n = (string) nombre;
            Debug.WriteLine("Hola " + n);
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(this.GoIdentificador);
            t.Name = "hilo secundario";
            t.Start();

            Thread.CurrentThread.Name = "PRINCIPAL";
            this.GoIdentificador();

        }

        private void GoIdentificador()
        {
            Debug.WriteLine("Hola desde: " + Thread.CurrentThread.Name);
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            Thread.CurrentThread.Priority = ThreadPriority.Highest;

            Thread t = new Thread(this.EscribeY);
            t.Priority = ThreadPriority.Lowest;
            t.Start();

            for (int i = 0; i < 1000; i++)
            {
                Debug.Write("X");
            }
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(this.LongGo);
            t.IsBackground = true;
            t.Start();
        }

        private void LongGo()
        {
            for (int i = 0; i < 1000; i++)
            {
                Thread.Sleep(500);
                Debug.Write("y");
            }
        }
    }
}
