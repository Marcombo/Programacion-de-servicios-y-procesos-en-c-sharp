﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace _05_ServidorPPT {
  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }

    string jugador1 = ""; //nick
    string idJug1 = ""; //referencia IP:port
    string jugada1 = ""; //piedra/papel/tijera
    int puntos1 = 0;
    string jugador2 = ""; //nick
    string idJug2 = ""; //referencia IP:port
    string jugada2 = ""; //piedra/papel/tijera
    int puntos2 = 0;
    private void ManejarCliente(TcpClient cli) {
      string data;
      NetworkStream ns = cli.GetStream();
      StreamReader sr = new StreamReader(ns);
      StreamWriter sw = new StreamWriter(ns);

      //informe de protocolo
      sw.WriteLine("#INSCRIBIR#nombre#");
      sw.WriteLine("#JUGADA#{piedra|papel|tijera}#");
      sw.WriteLine("#PUNTUACION#");
      sw.Flush();

      //escucha infinita de peticiones enviadas desde el cliente
      while (true) {
        try {
          data = sr.ReadLine(); //linea bloqueante
          Debug.WriteLine(data);
          String[] subdatos = data.Split('#');
          #region comINSCRIBIR
          if (subdatos[1] == "INSCRIBIR") {
            if (jugador1 == "") {
              jugador1 = subdatos[2];
              this.idJug1 = cli.Client.RemoteEndPoint.ToString();
              sw.WriteLine("#OK#");
              sw.Flush();
            } else if (jugador2 == "") {
              jugador2 = subdatos[2];
              this.idJug2 = cli.Client.RemoteEndPoint.ToString();
              sw.WriteLine("#OK#");
              sw.Flush();
            } else {
              sw.WriteLine("#NOK#ya hay dos jugadores#");
              sw.Flush();
            }
          }
          #endregion
          #region comJUGADA
          if (subdatos[1] == "JUGADA") {
            if ((subdatos[2] != "piedra") && (subdatos[2] != "papel") && (subdatos[2] != "tijera")) {
              sw.WriteLine("#NOK#valores válido: piedra/papel/tijera#");
              sw.Flush();
            }
            //comprobar quien hace la jugada
            else if ((idJug1 == cli.Client.RemoteEndPoint.ToString()) ||
                     (idJug2 == cli.Client.RemoteEndPoint.ToString())) {
              if (idJug1 == cli.Client.RemoteEndPoint.ToString()) { //estamos en el jugador 1
                jugada1 = subdatos[2];

                //pausar hasta que jugador 2 no haga su jugada
                while (jugada2 == "") Thread.Sleep(100);
              } else {  //estamos en el jugador2
                jugada2 = subdatos[2];
                //pausar hasta que el jugador 1 no haga su jugada
                while (jugada1 == "") Thread.Sleep(100);

              }
              //resolver la jugada
              //gana el 1
              if ((jugada1 == "piedra" && jugada2 == "tijera") ||
                  (jugada1 == "tijera" && jugada2 == "papel") ||
                  (jugada1 == "papel" && jugada2 == "piedra")) {
                sw.WriteLine("#OK#GANAOR:" + jugador1 + "#");
                sw.Flush();
                puntos1++;
              }
              //gana el 2
              else if ((jugada2 == "piedra" && jugada1 == "tijera") ||
                  (jugada2 == "tijera" && jugada1 == "papel") ||
                  (jugada2 == "papel" && jugada1 == "piedra")) {
                sw.WriteLine("#OK#GANAOR:" + jugador2 + "#");
                sw.Flush();
                puntos2++;
              }
              //empate
              else {
                sw.WriteLine("#OK#EMPATE#");
                sw.Flush();
              }

              //pequeña trampilla para que no colapsen los hilos
              Thread.Sleep(1000);
              jugada1 = "";
              jugada2 = "";
            } else {
              sw.WriteLine("#NOK#el jugador no esta en la partida#");
              sw.Flush();
            }
          }
          #endregion
          #region comPUNTUACION
          if (subdatos[1] == "PUNTUACION") {
            sw.WriteLine("#OK#" + jugador1 + ":" + puntos1.ToString() + "#"
                               + jugador2 + ":" + puntos2.ToString() + "#");
            sw.Flush();
          }
          #endregion


        }
        catch (Exception error) {
          Debug.WriteLine("Error: " + error.ToString());
        }
      }
    }

    private void Button1_Click(object sender, EventArgs e) {
      TcpListener newsock = new TcpListener(IPAddress.Any, 2000);
      newsock.Start();

      //escucha infinita de clientes que se quieran conecar
      while (true) {
        TcpClient client = newsock.AcceptTcpClient(); //linea bloquente
        Thread t = new Thread(() => this.ManejarCliente(client));
        t.Start();
      }
    }
  }
}
