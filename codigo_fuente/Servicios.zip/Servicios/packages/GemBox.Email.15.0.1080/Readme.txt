𝓔𝔁𝓪𝓶𝓹𝓵𝓮𝓼

The examples are the fastest way to get started with GemBox.Email.

To see the live examples and demos, go to Example Explorer: https://www.gemboxsoftware.com/email/examples

To download the examples C# and VB.NET projects, go to GitHub: https://github.com/GemBoxLtd/GemBox.Email.Examples


𝓥𝓮𝓻𝓼𝓲𝓸𝓷𝓼

You need to call the 𝚂𝚎𝚝𝙻𝚒𝚌𝚎𝚗𝚜𝚎 method before using any other member from GemBox.Email.

For the 𝗙𝗥𝗘𝗘 version, use the "𝙵𝚁𝙴𝙴-𝙻𝙸𝙼𝙸𝚃𝙴𝙳-𝙺𝙴𝚈" as following:

    𝙲𝚘𝚖𝚙𝚘𝚗𝚎𝚗𝚝𝙸𝚗𝚏𝚘.𝚂𝚎𝚝𝙻𝚒𝚌𝚎𝚗𝚜𝚎("𝙵𝚁𝙴𝙴-𝙻𝙸𝙼𝙸𝚃𝙴𝙳-𝙺𝙴𝚈")

For the 𝗣𝗥𝗢𝗙𝗘𝗦𝗦𝗜𝗢𝗡𝗔𝗟 version, replace "𝙵𝚁𝙴𝙴-𝙻𝙸𝙼𝙸𝚃𝙴𝙳-𝙺𝙴𝚈" with your license key.
You can purchase the license from our webshop: https://www.gemboxsoftware.com/email/pricelist


𝓢𝓾𝓹𝓹𝓸𝓻𝓽

• Contact Us: https://support.gemboxsoftware.com/new-ticket
• Forum: https://forum.gemboxsoftware.com/c/gembox-email
• Blog: https://www.gemboxsoftware.com/gembox-email
• API Reference: https://www.gemboxsoftware.com/email/docs