﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
namespace _10_ServidorPPTFullDuplex {
  public partial class Form1 : Form {

    Object o = new object(); //para hacer lock

    string jugador1 = ""; //nick
    string idJug1 = ""; //referencia IP:port
    string jugada1 = ""; //piedra/papel/tijera
    int puntos1 = 0;
    string jugador2 = ""; //nick
    string idJug2 = ""; //referencia IP:port
    string jugada2 = ""; //piedra/papel/tijera
    int puntos2 = 0;

    string listenPort1 = "";
    string listenPort2 = "";
    string ipJug1 = "";
    string ipJug2 = "";

    //datos para almacenar jugadas y resultados
    int numJugada = 1; //índice de la jugada en curso
    string[] textoVueltaJugada = new string[100]; //guarda resultado jugadas (histórico)

    public Form1() {
      InitializeComponent();
    }

    private void ManejarCliente(TcpClient cli) {
      string data;
      NetworkStream ns = cli.GetStream();
      StreamReader sr = new StreamReader(ns);
      StreamWriter sw = new StreamWriter(ns, Encoding.UTF8); //para ñ y acentos (no funciona con telnet, solo clientes .net)

      //informe de protocolo
      sw.WriteLine("#INSCRIBIR#nombre#puertoEscucha#");
      sw.WriteLine("#JUGADA#{piedra|papel|tijera}#");
      sw.WriteLine("#PUNTUACION#");
      sw.Flush();

      //escucha infinita de peticiones enviadas desde el cliente
      while (true) {
        try {
          data = sr.ReadLine(); //linea bloqueante
          Debug.WriteLine(data);
          String[] subdatos = data.Split('#');
          #region comINSCRIBIR
          if (subdatos[1] == "INSCRIBIR") {
            if (jugador1 == "") {
              jugador1 = subdatos[2];
              this.idJug1 = cli.Client.RemoteEndPoint.ToString();
              this.ipJug1 = idJug1.Split(':')[0];
              this.listenPort1 = subdatos[3];
              sw.WriteLine("#OK#");
              sw.Flush();
            } else if (jugador2 == "") {
              jugador2 = subdatos[2];
              this.idJug2 = cli.Client.RemoteEndPoint.ToString();
              this.ipJug2 = idJug2.Split(':')[0];
              this.listenPort2 = subdatos[3];
              sw.WriteLine("#OK#");
              sw.Flush();
            } else {
              sw.WriteLine("#NOK#ya hay dos jugadores#");
              sw.Flush();
            }
          }
          #endregion
          #region comJUGADA
          if (subdatos[1] == "JUGADA") {
            if ((subdatos[2] != "piedra") && (subdatos[2] != "papel") && (subdatos[2] != "tijera")) {
              sw.WriteLine("#NOK#valores válido: piedra/papel/tijera#");
              sw.Flush();
            }
            //comprobar quien hace la jugada
            else if ((idJug1 == cli.Client.RemoteEndPoint.ToString()) ||
                     (idJug2 == cli.Client.RemoteEndPoint.ToString())) {
              if (idJug1 == cli.Client.RemoteEndPoint.ToString()) { //estamos en el jugador 1
                jugada1 = subdatos[2];
              } else {  //estamos en el jugador2
                jugada2 = subdatos[2];
              }
              sw.WriteLine("#OK#" + this.numJugada + "#");
              sw.Flush();

              lock (o) //solo uno puede comprobar
              {
                //comprobar si tengo emitidas el par de jugadas
                if (jugada1 != "" && jugada2 != "") {
                  CompruebaGanador();
                  this.ComunicarResultadoClientes();
                  this.numJugada++; //pasamos a la siguiente jugada
                  this.jugada1 = "";
                  this.jugada2 = "";
                }
              }
            }
          }
          #endregion
          #region comPUNTUACION
          if (subdatos[1] == "PUNTUACION") {
            sw.WriteLine("#OK#" + jugador1 + ":" + puntos1.ToString() + "#"
                               + jugador2 + ":" + puntos2.ToString() + "#");
            sw.Flush();
          }
          #endregion
        }
        catch (Exception error) {
          Debug.WriteLine("Error: " + error.ToString());
        } //end catch
      } //end while
    } //end metodo

    private void button1_Click(object sender, EventArgs e) {
      //thread de recepción de clientes
      Thread t = new Thread(this.EsperarClientes);
      t.Start();
      this.button1.Enabled = false;
    }

    private void EsperarClientes() {
      TcpListener newsock = new TcpListener(IPAddress.Any, 2000);
      newsock.Start();

      //escucha infinita de clientes que se quieran conectar
      while (true) {
        TcpClient client = newsock.AcceptTcpClient(); //linea bloquente
        Thread t = new Thread(() => this.ManejarCliente(client));
        t.Start();
      }
    }

    private void CompruebaGanador() {
      //resolver la jugada
      //gana el 1
      if ((jugada1 == "piedra" && jugada2 == "tijera") ||
          (jugada1 == "tijera" && jugada2 == "papel") ||
          (jugada1 == "papel" && jugada2 == "piedra")) {
        this.textoVueltaJugada[numJugada - 1] = "#OK#GANDOR:" + this.jugador1 + "#";
        puntos1++;
      }
      //gana el 2
      else if ((jugada2 == "piedra" && jugada1 == "tijera") ||
          (jugada2 == "tijera" && jugada1 == "papel") ||
          (jugada2 == "papel" && jugada1 == "piedra")) {
        this.textoVueltaJugada[numJugada - 1] = "#OK#GANDOR:" + this.jugador2 + "#";
        puntos2++;
      }
      //empate
      else {
        this.textoVueltaJugada[numJugada - 1] = "#OK#EMPATE#";
      }
    }

    string dato;
    delegate void DelegadoRespuesta();
    private void EscribirFormulario() {
      this.label1.Text += dato + "@@@";
    }

    private void ComunicarResultadoClientes() {
      //comunico resultado a los clientes
      TcpClient cliente;
      NetworkStream ns;
      StreamReader sr;
      StreamWriter sw;

      DelegadoRespuesta dr = new DelegadoRespuesta(EscribirFormulario);

      //enviar info al primer ciente;
      cliente = new TcpClient(ipJug1, System.Convert.ToInt32(this.listenPort1));
      ns = cliente.GetStream();
      sr = new StreamReader(ns);
      sw = new StreamWriter(ns);
      sw.WriteLine(textoVueltaJugada[numJugada - 1]);
      sw.Flush();
      dato = sr.ReadLine();
      //this.label1.Text = dato;
      cliente.Close();
      this.Invoke(dr);

      //enviar info al segundo ciente;
      cliente = new TcpClient(ipJug2, System.Convert.ToInt32(this.listenPort2));
      ns = cliente.GetStream();
      sr = new StreamReader(ns);
      sw = new StreamWriter(ns);
      sw.WriteLine(textoVueltaJugada[numJugada - 1]);
      sw.Flush();
      dato = sr.ReadLine();
      //this.label1.Text = dato;
      cliente.Close();
      this.Invoke(dr);
    }
  }
}
