﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using System.Windows.Forms;

namespace _06_ClientePPT {
  public partial class Form1 : Form {
    TcpClient client;
    NetworkStream ns;
    StreamReader sr;
    StreamWriter sw;
    String dato;
    public Form1() {
      InitializeComponent();
    }

    private void Button1_Click(object sender, EventArgs e) {
      try {
        client = new TcpClient(this.textBox1.Text, 2000);
        ns = client.GetStream();
        sr = new StreamReader(ns);
        sw = new StreamWriter(ns);
        dato = sr.ReadLine() + System.Environment.NewLine +
               sr.ReadLine() + System.Environment.NewLine +
               sr.ReadLine();
        this.label1.Text = dato;
      }
      catch (Exception error) {
        Debug.WriteLine("Error: " + error.ToString());
      }
    }

    private void Button2_Click(object sender, EventArgs e) {
      sw.WriteLine("#INSCRIBIR#" + this.textBox2.Text + "#");
      sw.Flush();
      dato = sr.ReadLine();
      this.label1.Text = dato;
    }

    private void Button3_Click(object sender, EventArgs e) {
      sw.WriteLine("#JUGADA#" + this.comboBox1.Text + "#");
      sw.Flush();
      dato = sr.ReadLine();
      this.label1.Text = dato;
    }

    private void Button4_Click(object sender, EventArgs e) {
      sw.WriteLine("#PUNTUACION#");
      sw.Flush();
      dato = sr.ReadLine();
      this.label1.Text = dato;
    }
  }
}
