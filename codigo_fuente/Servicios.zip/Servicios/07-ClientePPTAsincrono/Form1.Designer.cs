﻿
namespace _07_ClientePPTAsincrono {
  partial class Form1 {
    /// <summary>
    /// Variable del diseñador necesaria.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Limpiar los recursos que se estén usando.
    /// </summary>
    /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
    protected override void Dispose(bool disposing) {
      if (disposing && (components != null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Código generado por el Diseñador de Windows Forms

    /// <summary>
    /// Método necesario para admitir el Diseñador. No se puede modificar
    /// el contenido de este método con el editor de código.
    /// </summary>
    private void InitializeComponent() {
      this.comboBox1 = new System.Windows.Forms.ComboBox();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.button4 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button1 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // comboBox1
      // 
      this.comboBox1.FormattingEnabled = true;
      this.comboBox1.Items.AddRange(new object[] {
            "piedra",
            "papel",
            "tijera"});
      this.comboBox1.Location = new System.Drawing.Point(170, 129);
      this.comboBox1.Name = "comboBox1";
      this.comboBox1.Size = new System.Drawing.Size(122, 21);
      this.comboBox1.TabIndex = 15;
      // 
      // textBox2
      // 
      this.textBox2.Location = new System.Drawing.Point(170, 76);
      this.textBox2.Name = "textBox2";
      this.textBox2.Size = new System.Drawing.Size(123, 20);
      this.textBox2.TabIndex = 14;
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(170, 21);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(123, 20);
      this.textBox1.TabIndex = 13;
      this.textBox1.Text = "127.0.0.1";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(29, 236);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(35, 13);
      this.label1.TabIndex = 12;
      this.label1.Text = "label1";
      // 
      // button4
      // 
      this.button4.Location = new System.Drawing.Point(26, 183);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(112, 32);
      this.button4.TabIndex = 11;
      this.button4.Text = "Puntuación";
      this.button4.UseVisualStyleBackColor = true;
      this.button4.Click += new System.EventHandler(this.Button4_Click);
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(26, 126);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(112, 32);
      this.button3.TabIndex = 10;
      this.button3.Text = "Jugar";
      this.button3.UseVisualStyleBackColor = true;
      this.button3.Click += new System.EventHandler(this.Button3_Click);
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(26, 69);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(112, 32);
      this.button2.TabIndex = 9;
      this.button2.Text = "Inscribir";
      this.button2.UseVisualStyleBackColor = true;
      this.button2.Click += new System.EventHandler(this.Button2_Click);
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(26, 12);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(112, 32);
      this.button1.TabIndex = 8;
      this.button1.Text = "Conectar";
      this.button1.UseVisualStyleBackColor = true;
      this.button1.Click += new System.EventHandler(this.Button1_Click);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(800, 450);
      this.Controls.Add(this.comboBox1);
      this.Controls.Add(this.textBox2);
      this.Controls.Add(this.textBox1);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.button4);
      this.Controls.Add(this.button3);
      this.Controls.Add(this.button2);
      this.Controls.Add(this.button1);
      this.Name = "Form1";
      this.Text = "Form1";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.ComboBox comboBox1;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Button button4;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button1;
  }
}

