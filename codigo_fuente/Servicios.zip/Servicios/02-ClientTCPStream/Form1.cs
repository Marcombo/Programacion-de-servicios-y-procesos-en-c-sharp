﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using System.Windows.Forms;

namespace _02_ClientTCPStream {
  public partial class Form1 : Form {
    TcpClient client;
    NetworkStream ns;
    StreamReader sr;
    StreamWriter sw; 
    public Form1() {
      InitializeComponent();
    }
    private void Button1_Click(object sender, EventArgs e) {
      try {
        client = new TcpClient(this.textBox1.Text, 2000);
        //Debug.WriteLine(client.Client.LocalEndPoint.ToString());
        //Debug.WriteLine(client.Client.RemoteEndPoint.ToString());
        ns = client.GetStream();
        sr = new StreamReader(ns);
        sw = new StreamWriter(ns);
        string mensaje_srv = sr.ReadLine();
        //Debug.WriteLine(mensaje_srv);
        this.label1.Text = mensaje_srv;
      }
      catch (Exception error) {
        this.label1.Text = error.ToString();
      }
  }

    private void Button2_Click(object sender, EventArgs e) {
      try {
        sw.WriteLine(this.textBox2.Text);
        sw.Flush();
        this.label1.Text = sr.ReadLine();
      }
      catch (Exception error) {
        this.label1.Text = error.ToString();
      }
    }
  }
}
