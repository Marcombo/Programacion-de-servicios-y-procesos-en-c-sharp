﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Net.Mail;

namespace _12_ServiciosSobreHTTP {
  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }

    //FTP: listar ficheros
    private void button1_Click(object sender, EventArgs e) {

      FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://ftp.dlptest.com/");
      request.Method = WebRequestMethods.Ftp.ListDirectory;
      //request.Method = WebRequestMethods.Ftp.ListDirectoryDetails;

      request.Credentials = new NetworkCredential("dlpuser", "rNrKYTX9g7z3RgJRmxWuGHbeu");

      FtpWebResponse response = (FtpWebResponse)request.GetResponse();

      Stream responseStream = response.GetResponseStream();
      StreamReader reader = new StreamReader(responseStream);
      Debug.WriteLine(reader.ReadToEnd());

      Debug.WriteLine("Listado del directorio raíz: " + response.StatusDescription);

      reader.Close();
      response.Close();
    }

    //FTP: subir un fichero
    private void button2_Click(object sender, EventArgs e) {
      FtpWebRequest request = (FtpWebRequest)WebRequest.Create(new Uri("ftp://ftp.dlptest.com" + "/" + "t1.txt"));
      request.Method = WebRequestMethods.Ftp.UploadFile;

      request.Credentials = new NetworkCredential("dlpuser", "rNrKYTX9g7z3RgJRmxWuGHbeu");

      byte[] fileContents;
      using (StreamReader sourceStream = new StreamReader("testfile1.txt")) {
        fileContents = Encoding.UTF8.GetBytes(sourceStream.ReadToEnd());
      }

      request.ContentLength = fileContents.Length;

      using (Stream requestStream = request.GetRequestStream()) {
        requestStream.Write(fileContents, 0, fileContents.Length);
      }

      using (FtpWebResponse response = (FtpWebResponse)request.GetResponse()) {
        Debug.WriteLine("Fichero subido con código: " + response.StatusDescription);
      }
    }
    private void button4_Click(object sender, EventArgs e) {
      //abrir web usando WebRequest
      //WebRequest request = WebRequest.Create("http://www.google.com");
      //WebResponse response = request.GetResponse();
      //Stream data = response.GetResponseStream();
      //string html = String.Empty;
      //using (StreamReader sr = new StreamReader(data)) {
      //  html = sr.ReadToEnd();
      //}
      ////this.textBox1.Text = html;
      //Debug.WriteLine(html);

      //abrir web usando WebClient
      WebClient client = new WebClient();
      client.Headers.Add("user-agent", "Cliente a través de aplicación .net Framework");

      Stream data = client.OpenRead("http://www.google.com");
      StreamReader reader = new StreamReader(data);
      string s = reader.ReadToEnd();
      this.textBox1.Text = s;
      Debug.WriteLine(s);
      data.Close();
      reader.Close();
  client.hee
    }


    private void button3_Click(object sender, EventArgs e) {

      MailAddress fromAddress = new MailAddress("jlcarnerosobrino@gmail.com", "From Luis");
      MailAddress toAddress = new MailAddress("jlcarnerosobrino@gmail.com", "To JoseLuis");

      SmtpClient clientSMTP = new SmtpClient
      {
        Host = "smtp.gmail.com",
        Port = 587,
        Credentials = new NetworkCredential(fromAddress.Address, "nuestro-password"),
        EnableSsl = true
      };
      //clientSMTP.Send("jlcarnerosobrino@gmail.com", "jlcarnerosobrino@gmail.com", "Prueba", "Hola desde el manual de threads & sockets");
      using (MailMessage message = new MailMessage(fromAddress, toAddress)
      {
        Subject = "Prueba",
        Body = "Hola desde el manual de threads & sockets"
      }) {
        clientSMTP.Send(message);
      }
    }

    private void button5_Click(object sender, EventArgs e) {
      System.Diagnostics.Process.Start("www.google.com");
    }
  }
}
