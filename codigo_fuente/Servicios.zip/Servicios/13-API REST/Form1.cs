﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Net.Mail;
using System.Net.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;



namespace _13_API_REST {
  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }

    private async void button1_Click(object sender, EventArgs e) {
      string apikey = "obtener una api - key!!!!";
      string ciudad = "ourense";
      string unidades = "metric";
      string url = $"https://api.openweathermap.org/data/2.5/weather?q="+ciudad+"&appid="+apikey+"&units="+unidades;
      using (HttpClient client = new HttpClient())
      using (HttpResponseMessage response = await client.GetAsync(url))
      using (HttpContent content = response.Content) {
        string cityData = await content.ReadAsStringAsync();
        Debug.WriteLine(cityData);

        //JObject json = JObject.Parse(cityData);
        //foreach (var item in json) {
        //  Debug.WriteLine(item);
        //}

        dynamic objDatosCiudad = JValue.Parse(cityData);
        string temperatura = objDatosCiudad.main.temp;

        Debug.WriteLine(temperatura);              
      }

    }

    private async void button2_Click(object sender, EventArgs e) {
      HttpContent datosEnvio = new StringContent("cod-persona");
      string url = $"https://psp-api.free.beeceptor.com/persona";
      using (HttpClient client = new HttpClient())
      using (HttpResponseMessage response = await client.PostAsync(url,datosEnvio))
      using (HttpContent content = response.Content) {
        string miPersonaJSON = await content.ReadAsStringAsync();
        //Debug.WriteLine(miPersonaJSON);
        Persona p = JsonConvert.DeserializeObject<Persona>(miPersonaJSON);
        Debug.WriteLine(p.nombre);
        Debug.WriteLine(p.edad.ToString());
      }      
    }
  }

  public class Persona {
    public string nombre;
    public int edad;
  }
}
