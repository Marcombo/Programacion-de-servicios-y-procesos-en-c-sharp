﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace _04_AdivinaNumeroMulti {
  public partial class Form1 : Form {
    int NumeroAdivinar = new Random().Next(1, 101);
    string data;
    public Form1() {
      InitializeComponent();
    }

    private void ManejarCliente(TcpClient cli) {
      NetworkStream ns = cli.GetStream();
      StreamReader sr = new StreamReader(ns);
      StreamWriter sw = new StreamWriter(ns);

      sw.WriteLine("Bienvenido!!, intenta adivinar mi numero");
      sw.Flush();

      //escucha infinita
      for (; ; ) {
        try {
          data = sr.ReadLine(); //linea bloqueante

          // this.label1.Text += data + System.Environment.NewLine;
          // this.label1.Refresh();
          Debug.WriteLine(data);

          //lógica adivinación
          int i;
          if (!int.TryParse(data, out i)) {
            sw.WriteLine("solo se permiten numeros");
            sw.Flush();
            break;
          }
          if (System.Convert.ToInt64(data) > this.NumeroAdivinar) {
            sw.WriteLine("mi numero es menor");
            sw.Flush();
          } else if (System.Convert.ToInt64(data) < this.NumeroAdivinar) {
            sw.WriteLine("mi numero es mayor");
            sw.Flush();
          } else {
            sw.WriteLine("HAS ACERTADO");
            sw.Flush();
            break;
          }
        }
        catch (Exception error) {
          Debug.WriteLine("Error: " + error.ToString());
        }
      }
      ns.Close();
      cli.Close();
    }


    private void Button1_Click(object sender, EventArgs e) {
      TcpListener newsock = new TcpListener(IPAddress.Any, 2000);
      newsock.Start();

      //escucha infinita de clientes que quieran conectarse
      while (true) {
        TcpClient client = newsock.AcceptTcpClient(); //linea bloqueante
        Thread t = new Thread(() => this.ManejarCliente(client));
        t.Start();
      }
    }
  }
}
