﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace _03_AdivinaNumero {

  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }

    int NumeroAdivinar = new Random().Next(1, 101);
    private void Button1_Click(object sender, EventArgs e) {
      string data;

      TcpListener servidor = new TcpListener(IPAddress.Any, 2000);
      servidor.Start(1);

      Debug.WriteLine("Esperando Cliente");
      TcpClient cliente = servidor.AcceptTcpClient(); //linea bloquante

      NetworkStream ns = cliente.GetStream();
      StreamReader sr = new StreamReader(ns);
      StreamWriter sw = new StreamWriter(ns);

      sw.WriteLine("Intenta adivinar mi numero");
      sw.Flush();

      this.label1.Text = "";

      //intercambio de información cliente-servidor
      while (true) {
        try {
          data = sr.ReadLine(); //linea bloqueante
          this.label1.Text += data + System.Environment.NewLine;
          this.label1.Refresh();

          //lógica adivinación
          int i;
          if (!int.TryParse(data, out i)) {
            sw.WriteLine("solo se permiten numeros");
            sw.Flush();
            break;
          }
          if (System.Convert.ToInt64(data) > this.NumeroAdivinar) {
            sw.WriteLine("mi numero es menor");
            sw.Flush();
          }
          else if (System.Convert.ToInt64(data) < this.NumeroAdivinar) {
            sw.WriteLine("mi numero es mayor");
            sw.Flush();
          }
          else {
            sw.WriteLine("HAS ACERTADO");
            sw.Flush();
            break;
          }
        }
        catch (Exception error) {
          Debug.WriteLine("Error: " + error.ToString());
        }
      }

      ns.Close();
      cliente.Close();
      servidor.Stop();
    }

  }
}
