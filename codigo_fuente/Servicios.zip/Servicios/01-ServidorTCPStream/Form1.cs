﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace _01_ServidorTCPStream {
  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }
    private void Button1_Click(object sender, EventArgs e) {
      string data;

      TcpListener servidor = new TcpListener(IPAddress.Any, 2000);
      servidor.Start();

      Debug.WriteLine("Esperando Cliente");
      TcpClient cliente = servidor.AcceptTcpClient(); //linea bloquante

      NetworkStream ns = cliente.GetStream();
      StreamReader sr = new StreamReader(ns);
      StreamWriter sw = new StreamWriter(ns);

      sw.WriteLine("Bienvenido");
      sw.Flush();

      this.label1.Text = "";

      //intercambio de información cliente-servidor
      while (true) {
        try {
          data = sr.ReadLine(); //linea bloqueante
          this.label1.Text += data + System.Environment.NewLine;
          this.label1.Refresh();

          //efecto eco
          sw.WriteLine("#" + data + "#");
          sw.Flush();
          if (data == "exit")
            break;
        }
        catch (Exception error) {
          Debug.WriteLine("Error: " + error.ToString());
        }
      }
      ns.Close();
      cliente.Close();
      servidor.Stop();
    }
  }
}
